﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int members = int.Parse(Console.ReadLine());
            Family family = new Family();
            for (int i = 0; i < members; i++)
            {
                string[] read = Console.ReadLine().Split();
                Person person = new Person(read[0], int.Parse(read[1]));
                family.AddMember(person);
            }
            Person oldest = family.GetOldestMember();
            Console.WriteLine($"{oldest.Name} {oldest.Age}");
        }
    }
}
