﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //int members = int.Parse(Console.ReadLine());
            //Family family = new Family();
            //for (int i = 0; i < members; i++)
            //{
            //    string[] read = Console.ReadLine().Split();
            //    Person person = new Person(read[0], int.Parse(read[1]));
            //    family.AddMember(person);
            //}
            //Person oldest = family.GetOldestMember();
            //Console.WriteLine($"{oldest.Name} {oldest.Age}");
            //family.GetMoreThenThirti();
            //DateTime startdate = DateTime.Parse(Console.ReadLine());
            //DateTime enddate = DateTime.Parse(Console.ReadLine());
            //DateModifier.CalculateDates(startdate, enddate);
            
            int carsCount = int.Parse(Console.ReadLine());
            List<Car> cars = new List<Car>();
            for (int i = 0; i < carsCount; i++)
            {
                string[] carDetails = Console.ReadLine().Split();
                Car car = new Car(carDetails[0], double.Parse(carDetails[1]) , double.Parse(carDetails[2]));
                cars.Add(car);
            }
            string input;
            while((input = Console.ReadLine()) != "End")
            {
                string[] currentCar = input.Split();
                Car car = new Car(currentCar[1], 0,0);
                Car car1 = cars.FirstOrDefault(c => c.Model == car.Model);
                int distance = int.Parse(currentCar[2]);
                car1.Drive(distance);
            }
            foreach (var car in cars)
            {
                Console.WriteLine($"{car.Model} {car.FuelAmount:f2} {car.TravelledDistance}");
            }
        }
    }
}
